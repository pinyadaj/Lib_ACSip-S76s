//;OoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO
//; File Name	 : acsip-lorawan-lib.c
//; Programmer   : Nopparat Ninsamran
//; Email@   	 : npr.ninsamran@gmail.com
//; Objective	 : ACSIP LoRaWan Library Implementation
//; Create(dd/mm/yy) : 07/02/2019
//; [Revision and Description]
//; Rev1.0 - 07/02/2019: Create Library by n.noparat
//;OoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//<>
//<> Section 1. Include File
//<>
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

/*  1.2. Third-Party Library <><><><><><><><><><><><><><><><><><><><><><><>*/
/*  1.1. Standard Library <><><><><><><><><><><><><><><><><><><><><><><><><> */

/*  1.3. User Library <><><><><><><><><><><><><><><><><><><><><><><><><><><>*/
#include "acsip-lorawan-lib.h"
// / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /
//
// Section 2. Public Variable Declare
//
// / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /
/* 2.1. Pointer to Function \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/ */

/* 2.2. Pointer to Variable \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/ */

/* 2.3. Memory mapping and ISR Variable \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/ */


/* 2.4. General Variable \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\ */
static char modem_buf[512];
uint8_t debug = 1;
acsip_ret_t return_code =  ACSIP_OK_RET;

/* 2.5. TABLE Variable \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\ */


// \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
//
// Section 3. Private Variable Declare
//
// \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
/* 3.1. Pointer to Function \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/ */

/* 3.2. Pointer to Variable \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/ */

/* 3.3. Memory mapping and ISR Variable \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/ */

/* 3.4. General Variable \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/ */

/* 3.5. TABLE Variable \/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\ */


//# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
//#
//# Section 4. Private struct and enum Declare
//#
//# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
/* 4.1. enum Declare # # # # # # # # # # # # # # # # # # # # # # # # # # # */


/* 4.2. struct Declare # # # # # # # # # # # # # # # # # # # # # # # # # # */

/* 4.3. function pointer Declare # # # # # # # # # # # # # # # # # # # # # */


//+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + 
//+
//+ Section 5. Private Function Prototype
//+
//+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + 
/* 5.1 general function Prototype* * * * * * * * * * * * * * * * * * * * * * * * */

/* 5.2. user library function Prototype* * * * * * * * * * * * * * * * * * * * * */


/* 5.3. Helper function Prototype* * * * * * * * * * * * * * * * * * * * * * * * */


//@ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ 
//@
//@ Section 6. Interrupt Service Routine
//@
//@ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ @ 


//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
//*
//* Section 7. Public Function Implement
//*
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
/* 7.1 general function * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* 7.2. user library function * * * * * * * * * * * * * * * * * * * * * * * * */

int16_t read_ack_uart2_blocked (int16_t fd, char* buf_pt, int32_t max_buf, int32_t tmout) {
int16_t len_cnt = 0;
uint32_t tick_byt_timeout = 0;
uint32_t prev_tick_byt_timeout = 0;
char* tmp_buf_pt;
uint8_t tmp_buf;
acsip_rx_state_t acsip_rx_state;

    tmp_buf_pt = buf_pt;

    prev_tick_byt_timeout = tick_byt_timeout = tick_sys;

    acsip_rx_state = ACSIP_RX_SOF1_STA;

    while (1) {
        // get timebase
        tick_byt_timeout = tick_sys;

        if ((tick_byt_timeout - prev_tick_byt_timeout) >= tmout) {
            *buf_pt = '\0';
            return -2;
        }

        // read data form uart2 queue
        if (os_getc_uart2(&tmp_buf, 5) == pdTRUE) {



            prev_tick_byt_timeout = tick_byt_timeout;
			switch (acsip_rx_state) {
				  case ACSIP_RX_SOF1_STA:
					  if (tmp_buf == (uint8_t)'>') {
						  len_cnt = 0;
						  *buf_pt = '\0';
						  acsip_rx_state = ACSIP_RX_SOF2_STA;
						//  LOG_INFO("ACSIP_RX_SOF1_STA-->OK");
					  }
					  break;

				  case ACSIP_RX_SOF2_STA:
					  if (tmp_buf == (uint8_t)'>') {
						  acsip_rx_state = ACSIP_RX_SOF3_STA;
						//  LOG_INFO("ACSIP_RX_SOF2_STA-->OK");
					  }
					  else {
						  acsip_rx_state = ACSIP_RX_SOF1_STA;
					  }
					  break;

				  case ACSIP_RX_SOF3_STA:
					  if (tmp_buf == (uint8_t)' ') {
						  acsip_rx_state = ACSIP_RX_DATA_STA;
						//  LOG_INFO("ACSIP_RX_SOF3_STA-->OK");
					  }
					  else {
						  acsip_rx_state = ACSIP_RX_SOF1_STA;
					  }
					  break;

				  case ACSIP_RX_DATA_STA:
					  if (len_cnt >= max_buf) {
						  len_cnt = 0;
						  buf_pt[0] = '\0';
						  return -1;
					  }

					  if (tmp_buf == (uint8_t)'\n') {
						  *tmp_buf_pt = '\0';
						 // LOG_INFO("ACSIP_RX_DATA_STA-->OK");
						  return len_cnt;
					  }

					  *tmp_buf_pt = (uint8_t) tmp_buf;
					  tmp_buf_pt++;
					  len_cnt++;

					  break;

				  default:
					  acsip_rx_state = ACSIP_RX_SOF1_STA;
					  break;
			}
        }
    }

    return len_cnt;
}


acsip_ret_t get_return_code(void) {
	return return_code;
}

void set_return_code(acsip_ret_t ret) {
	return_code = ret;
}

char* transfer_acsip (char* reqStr, char* ackStr, uint16_t tmout, int8_t crlf) {
char* ret_pt = NULL;
uint16_t ret_num = 0;

	for (int try_cnt = 0; try_cnt < SEND_AT_TRY_MAX; try_cnt++) {

		if (reqStr != NULL) {
			if (crlf) {SEND_AT_CMD_TO_MODEM(reqStr);}
			else {SEND_STRING_TO_MODEM(reqStr);}

			if (debug) {
				LOG_INFO("\r\n\r\n[DEBUG]: SND={ %s }\r\n",reqStr);
			}
		}
		else {
			if (debug) {
				LOG_INFO("\r\n\r\n[DEBUG]: SND.=\r\n");
			}
		}

		if (tmout == 0) {
			set_return_code(ACSIP_TIMEOUT_RET);
			break;
		}

		memset (modem_buf, 0, sizeof(modem_buf));

		ret_num = read_ack_uart2_blocked (0, modem_buf, sizeof(modem_buf), tmout);

		if (ret_num > 0) {
			set_return_code(ACSIP_OK_RET);

			ret_pt = modem_buf;

			if (ackStr != NULL) {
				ret_pt = strstr(modem_buf, ackStr);
				if(ret_pt == NULL) {
					set_return_code(ACSIP_TIMEOUT_RET);
					ret_pt = NULL;
					if (debug) LOG_INFO("[DEBUG]: RCV_FILTER = {\r\n%s\r\n}\r\n", modem_buf);
				}
				else {
					if (debug) LOG_INFO("[DEBUG]: RCV_FILTER = {\r\n%s\r\n}\r\n", ret_pt);
					return ret_pt;
				}
			}
			else {
				if (debug){
					LOG_INFO("[DEBUG]: RCV={\r\n%s\r\n}\r\n", modem_buf);
				}
				return ret_pt;
			}
		}
		else if (ret_num == -1) {
			set_return_code(ACSIP_BUFFER_OVERFLOW_RET);

			if (debug) {
				LOG_INFO("\r\n\r\n[DEBUG]: RCV: Buffer Overflow..(T_T)\r\n");
			}
		}
		else if (ret_num == -2) {
			set_return_code(ACSIP_TIMEOUT_RET);

			if (debug) {
				LOG_INFO("\r\n\r\n[DEBUG]: RCV: Timeout Occur..(T_T)\r\n");
			}
		}
	}

	 return ret_pt;
}

acsip_ret_t get_acsip (char* reqStr, char* filterStr, char *rep_buf, uint16_t rep_len_max, uint32_t tmout){
	*rep_buf = '\0';

	char* ret_str = transfer_acsip(reqStr, filterStr, tmout, 0);

	if (ret_str != NULL) {
		if ((rep_buf == NULL) || (rep_len_max <= strlen(ret_str))){
			set_return_code(ACSIP_BUFFER_OVERFLOW_RET);
		}else {
			strcpy(rep_buf, ret_str);
		}
	}

	return get_return_code();
}

// ************ SIP ************

acsip_ret_t sip_factory_reset_acsip (char *rep_buf, uint16_t len_max) {
	return get_acsip("sip factory_reset", NULL, rep_buf, len_max, 5000);
}

acsip_ret_t sip_get_ver_acsip (char *rep_buf, uint16_t len_max) {
	return get_acsip("sip get_ver", NULL, rep_buf, len_max, 1000);
}

acsip_ret_t sip_get_hw_deveui_acsip(char *rep_buf, uint16_t len_max) {
	return get_acsip("sip get_hw_deveui", NULL, rep_buf, len_max, 1000);
}

acsip_ret_t sip_reset_acsip(void) {
	transfer_acsip("sip reset", NULL, 5000, 0);
	return get_return_code();
}

acsip_ret_t sip_set_echo_acsip(int8_t on) {
	char snd_buf[128];
	sprintf(snd_buf, "sip set_echo %s", on ? "on": "off");
	transfer_acsip(snd_buf, "Ok", 1000, 0);
	return get_return_code();
}


// ************ MAC ************

acsip_ret_t mac_tx_acsip(char *type, int8_t port_num, uint8_t *data, uint32_t len) {
 char tmp_buf[255];
 uint8_t data_out[255] = {0};

	 if (bytesToHexStr(data, len, data_out, sizeof(data_out)) < 0) {
		 set_return_code(ACSIP_BUFFER_OVERFLOW_RET);
	 }
	 else {
		 //LOG_INFO("convert:: %s\n\r", data_out);
		 sprintf(tmp_buf, "mac tx %s %d %s", type, port_num, data_out);

		  transfer_acsip(tmp_buf, "Ok", 5000, 0);

		  if (get_return_code() == ACSIP_OK_RET) {
		   transfer_acsip(NULL, "tx_ok", 30000, 0);
		  }
	 }

	 return get_return_code();
}

acsip_ret_t mac_join_acsip(char *mode, char *rep_buf, uint16_t len_max) {
	char tmp_buf[128];

	for (int try_cnt = 0; try_cnt < SEND_AT_TRY_MAX; try_cnt++) {
		sprintf(tmp_buf, "mac join %s", mode);
		char* ret_str = transfer_acsip(tmp_buf, "Ok", 1000, 0);

		if (ret_str != NULL) {
			set_return_code(get_acsip(NULL, "accepted", rep_buf, len_max, 10000));
			break;
		}
	}
	return get_return_code();
}

acsip_ret_t mac_save_acsip(void) {
	transfer_acsip("mac save", "Ok", 3000, 0);
	return get_return_code();
}

acsip_ret_t mac_get_join_status_acsip(char *rep_buf, uint16_t len_max) {
	return get_acsip("mac get_join_status", NULL, rep_buf, len_max, 1000);
}

acsip_ret_t mac_set_deveui_acsip(char *deveui) {
	char tmp_buf[128];
	sprintf(tmp_buf, "mac set_deveui %s", deveui);
	transfer_acsip(tmp_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t mac_set_appeui_acsip(char *appeui) {
	char tmp_buf[128];
	sprintf(tmp_buf, "mac set_appeui %s", appeui);
	transfer_acsip(tmp_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t mac_set_appkey_acsip(char *appkey) {
	char tmp_buf[128];
	sprintf(tmp_buf, "mac set_appkey %s", appkey);
	transfer_acsip(tmp_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t mac_set_devaddr_acsip(char *devaddr) {
	char tmp_buf[128];
	sprintf(tmp_buf, "mac set_devaddr %s", devaddr);
	transfer_acsip(tmp_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t mac_set_nwkskey_acsip(char *nwkskey) {
	char tmp_buf[128];
	sprintf(tmp_buf, "mac set_nwkskey %s", nwkskey);
	transfer_acsip(tmp_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t mac_set_appskey_acsip(char *appskey) {
	char tmp_buf[128];
	sprintf(tmp_buf, "mac set_appskey %s", appskey);
	transfer_acsip(tmp_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t mac_set_freq_acsip(int8_t ch, uint32_t freq) {
	char tmp_buf[128];
	sprintf(tmp_buf, "mac set_ch_freq %d %lu", ch, freq);
	transfer_acsip(tmp_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t mac_get_deveui_acsip (char *rep_buf, uint16_t len_max) {
	return get_acsip("mac get_deveui", NULL, rep_buf, len_max, 1000);
}


// // ************ GPS ************

acsip_ret_t gps_set_level_shift_acsip(int8_t on) {
	char snd_buf[128];
	sprintf(snd_buf, "gps set_level_shift %s", on ? "on": "off");
	transfer_acsip(snd_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t gps_set_nmea_rmc_acsip(void) {
	transfer_acsip(" gps set_nmea rmc", "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t gps_set_port_uplink_acsip(char *port) {
	char tmp_buf[128];
	sprintf(tmp_buf, "gps set_port_uplink %s", port);
	transfer_acsip(tmp_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t gps_set_format_uplink_acsip(char *format) {
	char tmp_buf[128];
	sprintf(tmp_buf, "gps set_format_uplink %s", format);
	transfer_acsip(tmp_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t gps_set_positioning_cycle_acsip (uint32_t time) {
	char tmp_buf[128];
	sprintf(tmp_buf, "gps set_positioning_cycle %lu", time);
	transfer_acsip(tmp_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t gps_set_mode_acsip(char *mode) {
	char tmp_buf[128];
	sprintf(tmp_buf, "gps set_mode %s", mode);
	transfer_acsip(tmp_buf, "Ok", 1000, 0);
	return get_return_code();
}

acsip_ret_t gps_get_mode_acsip (char *rep_buf, uint16_t len_max) {
	return get_acsip("gps get_mode", NULL, rep_buf, len_max, 1000);
}

acsip_ret_t gps_get_data_acsip (char *req_buf, char *rep_buf, uint16_t len_max) {
	char tmp_buf[128];
	sprintf(tmp_buf, "gps get_data %s", req_buf);
	return get_acsip(tmp_buf, NULL, rep_buf, len_max, 1000);
}

//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
//*
//* Section 8. Private Function Implement
//*
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
/* 8.1 general function * * * * * * * * * * * * * * * * * * * * * * * * * * * */
const char hexArray[] = {'0', '1', '2', '3', '4', '5','6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

int16_t bytesToHexStr(uint8_t *buf_in, int32_t len_in, uint8_t *buf_out, int32_t len_out) {
int j = 0;
 	if(len_out < (len_in<<1)) return -1;

    for (j = 0; j < len_in; j++ ) {
        int v = buf_in[j] & 0xFF;
        buf_out[j * 2] = hexArray[v >> 4];
        buf_out[j * 2 + 1] = hexArray[v & 0x0F];
    }

    buf_out[len_in * 2] = 0;

    return 1;
}

/* 8.2. user library function * * * * * * * * * * * * * * * * * * * * * * * * */

/* 8.3. Helper function * * * * * * * * * * * * * * * * * * * * * * * * */


//------------------------------------------------------------------------------
//- END of File.
//------------------------------------------------------------------------------
